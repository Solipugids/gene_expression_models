kappa = 80; %pN*nm
mu = 0.1; %pN/nm
f = 20; %pN
r = linspace(10, 40,100); %nm
l = linspace(250,450,100); %nm
[R L] = meshgrid(r,l);

E = pi.*kappa.*L./R + 2.*pi.*mu.*R.*L - f.*L

surf(R,L,E,'EdgeColor','none');
xlabel('radius R');
ylabel('length L');
zlabel('Energy E');

R=r;
EpL = pi.*kappa./R + 2.*pi.*mu.*R - f;

figure(2);
plot(R,EpL);
xlabel('R');
ylabel('E');

[min_EpL,I] = min(EpL)
hold on;
plot(R(I),EpL(I),'o');

kappa = linspace(20,160,100);

[R Kappa] = meshgrid(r,kappa);
EpL = pi.*Kappa./R + 2.*pi.*mu.*R - f;
surf(R, Kappa, EpL,'EdgeColor','none');
xlabel('r');
ylabel('kappa');
zlabel('E');

%find the value of R and kapp  for minimal E
[min_EpL,I] = min(EpL,[],2);

Rstar = r(I);

figure(3);
plot(Rstar,kappa);
ylabel('kappa');
xlabel('Rstar');

plot(log(Rstar),log(kappa));

p = polyfit(log(Rstar),log(kappa),1);





