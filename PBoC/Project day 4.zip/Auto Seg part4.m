%% Analysing Autofluoresce Images
clear;
%load the segmentation image for autoflurescence
rootDir = 'c:\users\fw\Desktop\CSHL\';
img = imread([rootDir 'Auto\Auto-c-001.tif']);
figure(1);
imshow(img,[]);

%segmentatino by simple thresholding
figure(2);
imshow(img>130);

%median filtering in matlab
testImg = [1 1 1 10;1 10 1 10; 1 1 1 10]

%defining filter
testfilter = [ 1 1 1;1 1 1;1 1 1]/9
%filtering the test image
imfilter(testImg, testfilter,'symmetric')

%median filter
medfilt2(testImg,[3 3],'symmetric')

%median diltering the image
imgFiltered = medfilt2(img,[3 3], 'symmetric');
figure(2);
imshow(imgFiltered,[]);

%edge detection
imgEdge = edge(imgFiltered,'log',0);
figure(3);
imshow(imgEdge,[]);

imshow(imgFiltered,[100 107]);

%flatten the background
imgBGremoved = imgFiltered-106;
imgEdge2 = edge(imgBGremoved,'log',0);
figure(5);
imshow(imgEdge2,[]);

%filling the cells
imgMask = imfill(imgEdge2,'holes');
figure(6);
imshow(imgMask,[]);

%labeling the cells
imgSeg = bwlabel(imgMask);
figure(7);
imshow(imgSeg,[]);

%show only one cell
imshow(imgSeg==16);

%using regionprops to characterize the segmented area
segProp = regionprops(imgSeg,'all');

%introducing structure
s.b = 1
s.b
s.c = [1 2 3]
s.d = 'sdfsf'
s
s2.a = 1
s.e = s2

s3(1).a = 1;
s3(2).a = 10;
s3(3).a = 100;

s3

[s3(:).a]

segProp

%histogram of the areas of the segmented objects
figure(8);
hist([segProp(:).Area],30);

%removing small objects from imgMask, save to imgMask
figure(9);
imshow(imgMask);
imgMask2 = imgMask;
for i = 1 : length(segProp)
    if segProp(i).Area<100
        imgMask2(imgSeg==i) = 0;
    end
end
figure(10);
imshow(imgMask2);

testimg = [1 2 3;1 2 3;1 2 3]
testimg(logical([0 0 1; 0 0 1; 0 0 0]))

%labeling the cells
imgSeg2 = bwlabel(imgMask2);
figure(11);
imshow(imgSeg2,[]);

%loading the fluorescent images
imgY = imread([rootDir 'Auto\Auto-y-001.tif']);
imgR = imread([rootDir 'Auto\Auto-r-001.tif']);

figure(12);imshow(imgY,[100 110]);

imshow(imgY.*uint16(imgSeg2==11),[100 110]);
imshow(imgY.*uint16(imgSeg2>0),[100 110]);

figure(13);imshow(imgY.*uint16(imgSeg2==0),[100 110]);

area = [];
rcells=[];
ycells=[];
for i = 1:max(unique(imgSeg2))
   rcells(i)=sum(sum(imgR.*uint16(imgSeg2==i))); 
   ycells(i)=sum(sum(imgY.*uint16(imgSeg2==i))); 
   area(i) = sum(sum(imgSeg2==i));
end

figure(14);hist(ycells./area,10);

yAuto = mean(ycells./area)
rAuto = mean(rcells./area)

%% segmenting the movie
close all;
clear all;
yAuto = 104.8;
rAuto = 109.1;
rootDir = 'c:\users\fw\Desktop\CSHL\';

for i=1:20
    img = imread([rootDir 'Movie2\Pos15_0-c-' num2str(i,'%03d') '.tif']);
    %median diltering the image
    imgFiltered = medfilt2(img,[3 3], 'symmetric');
    %flatten the background
    imgBGremoved = imgFiltered-106;
    imgEdge2 = edge(imgBGremoved,'log',0);
    %filling the cells
    imgMask = imfill(imgEdge2,'holes');
    %labeling the cells
    imgSeg = bwlabel(imgMask);
    %using regionprops to characterize the segmented area
    segProp = regionprops(imgSeg,'all');
    %removing small objects from imgMask, save to imgMask
    imgMask2 = imgMask;
    for j = 1 : length(segProp)
        if segProp(j).Area<100 
            imgMask2(imgSeg==j) = 0;
        end
    end
       
    %labeling the cells
    imgSeg2 = bwlabel(imgMask2);
    segProp2 = regionprops(imgSeg2,'all');
    hist([segProp2(:).Perimeter]./[segProp2(:).Area])
    
    imgMask3 = imgMask2;
    for j = 1 : length(segProp2)
        if segProp2(j).Perimeter/segProp2(j).Area>0.5 
            imgMask3(imgSeg2==j) = 0;
        end
    end
       
    %labeling the cells
    imgSeg3 = bwlabel(imgMask3);
    segProp3 = regionprops(imgSeg3,'all');
    figure(1);imshow(imgSeg3,[]);
    figure(2);imshow(img,[]);
    pause(0.5);
end
   % hist(segProp(segProp.Area<100).Perimeter./segProp(segProp.Area<100).Area)
  %  || segProp(j).Perimeter/segProp(j).Area > 20
