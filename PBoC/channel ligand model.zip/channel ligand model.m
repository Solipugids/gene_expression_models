%% ploting the probability of a channel with one receptor as a funtion of
%% the ligand concentration
Eo = 0; 
Ec = -5; 
kdo = 10; 
kdc = 1000;
L = [1:1:100000];

Z = exp(-Ec) + exp(-Ec).* L./kdc + exp(-Eo) + exp(-Eo).*L./kdo;

p0 = exp(-Ec) ./ Z;
p1 = exp(-Ec) .* L./kdc ./ Z;
p2 = exp(-Eo) ./ Z;
p3 = exp(-Eo) .*L./kdo ./Z;

figure(11);
plot(L,p0,L,p1,L,p2,L,p3);
legend('closed, unbound', 'closed bound','open unbound', 'open bound' );
xlabel('ligand concentration');
ylabel('probability');
set(gca, 'xscale', 'log');
