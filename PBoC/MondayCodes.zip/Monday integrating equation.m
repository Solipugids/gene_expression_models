
% use the Euler method look how the systems progresses over time

% define the initial amount of stuff
N0 = 10; %# of molecules

% define the rate constant
k = 0.1; %units of 1/s

% define the timestep
timestep = 0.1; %units of s
% use timestep = 10 to see problems with timestep*k not < 1

% write a loop to move forward in time
N(1) = N0;
for t=2:100
    N(t) = N(t-1) - k * N(t-1) * timestep;
end

% plot N vs. time
% made a vector of time
time = [1:1:100]*timestep;

plot(time, N)
xlabel('time (s)')
ylabel('# of molecules')

% calculating the analytical solution
Ncalc = N0 * exp(-k*time);
hold on
plot(time, Ncalc, 'red')




