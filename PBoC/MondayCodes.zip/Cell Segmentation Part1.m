%% Analysing Autofluoresce Images
clear;
%load the segmentation image for autoflurescence
rootDir = 'c:\users\fw\Desktop\CSHL\';
img = imread([rootDir 'Auto\Auto-c-001.tif']);
figure(1);
imshow(img,[]);

%segmentatino by simple thresholding
figure(2);
imshow(img>130);

%median filtering in matlab
testImg = [1 1 1 10;1 10 1 10; 1 1 1 10]

%defining filter
testfilter = [ 1 1 1;1 1 1;1 1 1]/9
%filtering the test image
imfilter(testImg, testfilter,'symmetric')

%median filter
medfilt2(testImg,[3 3],'symmetric')

%median diltering the image
imgFiltered = medfilt2(img,[3 3], 'symmetric');
figure(2);
imshow(imgFiltered,[]);

%edge detection
imgEdge = edge(imgFiltered,'log',0);
figure(3);
imshow(imgEdge,[]);

imshow(imgFiltered,[100 107]);

%flatten the background
imgBGremoved = imgFiltered-106;
imgEdge2 = edge(imgBGremoved,'log',0);
figure(5);
imshow(imgEdge2,[]);

%filling the cells
imgMask = imfill(imgEdge2,'holes');
figure(6);
imshow(imgMask,[]);

%labeling the cells
imgSeg = bwlabel(imgMask);
figure(7);
imshow(imgSeg,[]);

