% look at when (1+1/n)^n converges to e

% define a vector n's
n = 1:1:20;

% making a vector of numbers
n2 = 1:1:5
n3 = 2:2:20

n = 1:1:20;
% calculate the estimate of e
y = (1+1./n).^n;

% plot n vs. y
plot(n,y)
xlabel('n')
ylabel('estimate of e')

hold on
y2 = n*0 + exp(1);

% plot y = e on the same plot
plot(n,y2, 'r--') 


% plot (1+2.3/n)^n
figure(2)

y3 = (1+2.3./n).^n;

plot(n,y3,n,y2)

% what happens wen n = 50
bigNum =50;
y4 = (1+2.3/bigNum)^bigNum





