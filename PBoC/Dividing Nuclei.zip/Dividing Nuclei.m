clear;
data = big_data
Dm = (data(:,2)+data(:,3))./2
Dd1 = (data(:,4)+data(:,5))./2
Dd2 = (data(:,6)+data(:,7))./2
figure(1);
plot(Dm,'ko');
hold on;
plot(Dd1,'bo');
plot(Dd2,'ro');

figure(2);
plot(Dm./Dd1,'bo');
hold on;
plot(Dm./Dd2,'ro');
plot([1 12],[2^(1/3) 2.^(1/3)],'r--');
plot([1 12],[2^(1/2) 2.^(1/2)],'g--');
hold off;
xlabel('index');
ylabel('diameter of nuclei');
legend('Dm/Dd1','Dm/Dd2','model prediction equal Volume','model prediction equal Area');
axis([1 12 0 2.5]);

figure(3);

plot(Dd1,Dd2,'o');
hold on;
plot([0 3],[0 3],'--');
