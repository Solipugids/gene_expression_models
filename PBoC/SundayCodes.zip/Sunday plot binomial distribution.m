
% # of flips
N = 100;
% probability of success
p = 0.5;
% number of successes
K = 50;

% calculate factorials in matlab
factorial(170)

pK = factorial(N)/(factorial(K)*factorial(N-K)) * p^K * (1-p)^(N-K)

% define a vector of Ks
K = 0:1:100
K = linspace(0,100, 101)

%element wise operations
A = [1 2 3];
B = [1 2 3];
% A*B doesn't work
A*B
% A.*B elementwise multiplication
A.*B

% calculate the p(K) for K between 0 and 100
pK = factorial(N)./ (factorial(K) .* factorial(N-K)) .* p.^K .* (1-p).^(N-K);

%graph it
plot(K,pK)
xlabel('K')
ylabel('probability of K')

% use binopdf to plot the distribution
pK = binopdf(K,N,0.5);
plot(K,pK)
xlabel('K')
ylabel('probability of K')
hold on
pK = binopdf(K,N,0.1);
plot(K,pK,'red')
pK = binopdf(K,N,0.01);
plot(K,pK,'green')

