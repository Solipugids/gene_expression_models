% use matlab to calculate E. coli division time

% look at the picture of the first cell
colony = imread('Colony_growth_0001.jpg');
imshow(colony)

% find the cells in the picture by using the fact that the cells is
% made of low numbers pixels

test = [10 15 23; 15 125 25; 15 16 87];
test==23
threshold = 50;
test>threshold

% look at the colony after it has grown
colony2 = imread('Colony_growth_0025.jpg');
imshow(colony2)

% look at the range of pixel values
max(max(colony2))
min(min(colony2))

% let's try different threshold values
threshold = 50;
colony2_thresh = colony2<threshold;
imshow(colony2_thresh)

% by vote the threshold is 75

% how to calculate colony area
threshold = 72;
colony2_thresh = colony2<threshold;
imshow(colony2_thresh)

% add the ones in the picture
sum(sum(colony2_thresh))

% write a loop to analyze all the images
test_loop(1) = 1^2;
test_loop(2) = 2^2;

% write a loop to calc squares of integers
for i=1:20
    loop(i) = i^2;
end

loop

% read in the file names
i = 20;
File = sprintf('Colony_growth_%04.f.jpg',i)


% now we will write the loop to anaylze all the images
for i = 1:27
File = sprintf('Colony_growth_%04.f.jpg',i);
colony = imread(File);
colony_thresh = colony < threshold;
area(i) = sum(sum(colony_thresh));
end

% look at the plot of the area
plot(area)
xlabel('time')
ylabel('area in pixels')

plot(log(area))

% create a vector of time in minutes
time = 0:10:260;

% fit the line to y = mx+b, output is bestfit slope and intercept
fitk = polyfit(time,log(area),1)

% calculate the doubling time in minutes
log(2) / fitk(1)







