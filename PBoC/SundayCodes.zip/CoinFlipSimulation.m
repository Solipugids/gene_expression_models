%n coin flips per experiment
n=50;
%fair coin with p=0.5
p=0.5;
%coin flip
rand<=p;
%vector of coinflips
k=rand(n,1)<=p;
X=sum(k)
%lets do 1000 experiments
X=[];
for i = 1:10000
    k=rand(n,1)<=p;
    X(i)=sum(k);
end
figure(1);
hist(X,[0:1:50]);

mean(X)
var(X)
xlabel('k');
ylabel('frequency');

%with randomized probability
%n coin flips per experiment
n=50;
X=[];
for i = 1:10000
    p=rand;
    k=rand(n,1)<=p;
    X(i)=sum(k);
end
figure(2);
hist(X,[0:1:50]);

mean(X)
var(X)
xlabel('k');
ylabel('frequency');
