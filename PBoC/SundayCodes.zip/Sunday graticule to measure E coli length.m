% use the graticule to find the size of a single bacteria
Graticule = imread('100X graticule jpg.jpg');

% look at the picture
imshow(Graticule)

% what are the properties of Graticule
whos Graticule

% what is a picture in matlab?
A = [1 0 0; 0 0.5 1; 0  1 0];

% look at A as a picture
imshow(A)

% scale the gray values in the image
imshow(A,[0.2, 0.8])

% look at variable
A
Graticule(:,:,1)

Graticule(1,1,1)
Graticule(:,1,1)


% use the graticulet to determine how big a pixel is
imshow(Graticule)

% plot a crosssection of the graticule
Graticule_cut = Graticule(600,:,2);

% look at the cross section
plot(Graticule_cut)

% label the plot
figure(1)
xlabel('distance (pixels)')
ylabel('intensity')

% calculate microns per pixel from the graticule plot
micronperpixel = 50/1050;

% now look at the E. coli picture
Ecoli = imread('E coli with scale bar jpg.jpg');
imshow(Ecoli)

% estimate E coli length by zooming on an E coli
imtool(Ecoli)

% by zooming in, the E. coli is about 43 pixels
% convert to size in microns
43*micronperpixel



