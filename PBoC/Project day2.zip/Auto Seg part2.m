%% Analysing Autofluoresce Images
clear;
%load the segmentation image for autoflurescence
rootDir = 'c:\users\fw\Desktop\CSHL\';
img = imread([rootDir 'Auto\Auto-c-001.tif']);
figure(1);
imshow(img,[]);

%segmentatino by simple thresholding
figure(2);
imshow(img>130);

%median filtering in matlab
testImg = [1 1 1 10;1 10 1 10; 1 1 1 10]

%defining filter
testfilter = [ 1 1 1;1 1 1;1 1 1]/9
%filtering the test image
imfilter(testImg, testfilter,'symmetric')

%median filter
medfilt2(testImg,[3 3],'symmetric')

%median diltering the image
imgFiltered = medfilt2(img,[3 3], 'symmetric');
figure(2);
imshow(imgFiltered,[]);

%edge detection
imgEdge = edge(imgFiltered,'log',0);
figure(3);
imshow(imgEdge,[]);

imshow(imgFiltered,[100 107]);

%flatten the background
imgBGremoved = imgFiltered-106;
imgEdge2 = edge(imgBGremoved,'log',0);
figure(5);
imshow(imgEdge2,[]);

%filling the cells
imgMask = imfill(imgEdge2,'holes');
figure(6);
imshow(imgMask,[]);

%labeling the cells
imgSeg = bwlabel(imgMask);
figure(7);
imshow(imgSeg,[]);

%show only one cell
imshow(imgSeg==16);

%using regionprops to characterize the segmented area
segProp = regionprops(imgSeg,'all');

%introducing structure
s.b = 1
s.b
s.c = [1 2 3]
s.d = 'sdfsf'
s
s2.a = 1
s.e = s2

s3(1).a = 1;
s3(2).a = 10;
s3(3).a = 100;

s3

[s3(:).a]

segProp

%histogram of the areas of the segmented objects
figure(8);
hist([segProp(:).Area],30);

%removing small objects from imgMask, save to imgMask
figure(9);
imshow(imgMask);
imgMask2 = imgMask;
for i = 1 : length(segProp)
    if segProp(i).Area<100
        imgMask2(imgSeg==i) = 0;
    end
end
figure(10);
imshow(imgMask2);

testimg = [1 2 3;1 2 3;1 2 3]
testimg(logical([0 0 1; 0 0 1; 0 0 0]))
