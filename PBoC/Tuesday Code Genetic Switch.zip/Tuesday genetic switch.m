
% create a grid of points to caculate the derivatives
Rvect = linspace(0,5,80);
Bvect = linspace(0,5,80);
[Rmesh,Bmesh] = meshgrid(Rvect(1:3:end), Bvect(1:3:end));

% define some constants
gamma = 1; % degradation rate (1/s)
alpha = 3; % production rate (molecule/s)
Kd = 1; % dissociation constant (molecules)

% calculate the vectors at each point
dRdt = - gamma.*Rmesh + alpha ./ (1+(Bmesh./Kd).^2);
dBdt = - gamma.*Bmesh + alpha ./ (1+(Rmesh./Kd).^2);

% plot the phase portrait
quiver(Rmesh, Bmesh, dRdt, dBdt, 1.5, 'LineWidth', 1)
xlabel('R')
ylabel('B')