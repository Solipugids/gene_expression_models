clear;
%target = zeros(200);
figure(1);
hold on;
%imagesc(target);
hits =0;
n=100000;
for i = 1:n
    
    dart = rand(2,1).*2-1;
    if sum(dart.^2)<1
        hits = hits+1;
        %plot(dart(1),dart(2),'ro');
    else
        %plot(dart(1),dart(2),'bo');
        %pause(0.01);
    end
    %hold on;
    %pause(0.1);
    %text(dart(1),dart(2),num2str(hits/i*4 ,'%.4f'),'FontSize',10,'Color','magenta');
     if mod(i,200)==0
         hits/i*4
     end
end
hits/n*4