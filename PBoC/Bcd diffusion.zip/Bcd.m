L=500;  %Length of the embryo in um

TotalTime=30000;	%Total time for integration in seconds
dx=10;      %Size of the box in um
dt=1;      %Time step in seconds

D=18;        %Diffusion constant in um^2/s
lambda=L*.18;  %Decay length in um

%tau=50*60;  %Decay time in seconds
%Calculate tau given D and lambda
tau=lambda^2/D;

R=10;       %Production rate in Bcd/s


Bcd=zeros(TotalTime/dt,L/dx);       %We define a matrix where the rows keep
                                    %track of time and the columns keep
                                    %track of the position.
                                   
                                    
%Let's start by moving through time using the index i. Notice that we are
%starting at the second time point.
for i=2:TotalTime/dt
    
    %First, calculate the evolution of the concentration at the first box
    Bcd(i,1)=Bcd(i-1,1)-dt/tau*Bcd(i-1,1)+...
        D*dt/dx^2*(Bcd(i-1,2)-Bcd(i-1,1))+R*dt;
    
    %Calculate the evolution in the middle boxes
    for j=2:(L/dx-1)
        Bcd(i,j)=Bcd(i-1,j)-dt/tau*Bcd(i-1,j)-D*dt/dx^2*(Bcd(i-1,j)-Bcd(i-1,j-1))+...
            D*dt/dx^2*(Bcd(i-1,j+1)-Bcd(i-1,j));
    end
    
    %Calculate the evolution at the last box
    Bcd(i,L/dx)=Bcd(i-1,L/dx)-dt/tau*Bcd(i-1,L/dx)+...
        D*dt/dx^2*(Bcd(i-1,L/dx-1)-Bcd(i-1,L/dx));
end
    

%Plot the profile as a function of position for different time points
xRange=1:dx:L;
 
plot(xRange,Bcd(TotalTime/dt,:),'-k')
hold on
plot(xRange,Bcd(15000/dt,:),'-r')
plot(xRange,Bcd(1500/dt,:),'-g')
plot(xRange,Bcd(150/dt,:),'-b')
hold off

%Plot the profile as a function of time for a particular box
tRange=1:dt:TotalTime;
plot(tRange,Bcd(:,40))



    
    
    